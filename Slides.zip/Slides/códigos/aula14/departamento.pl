/* Departamento                        */
/*         NumDepto, Nome, MatGerente  */

:- dynamic departamento/3.

departamento(1, 'Relações Públicas', 21).
departamento(2, 'Segurança',         43).
