created(1623449266.4202597).
assert(bookmark(1,"Google","https://www.google.com")).
assert(bookmark(2,"index | TIOBE - The Software Quality Company","https://www.tiobe.com/tiobe-index/")).
